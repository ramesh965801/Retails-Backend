package com.retail.RM_RETAIL;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RmRetailApplication {

	public static void main(String[] args) {
		SpringApplication.run(RmRetailApplication.class, args);
	}

}
